# Qwen3.7-Max 异常停止 Bug 上报资料

## 一、问题概述

`qwen3.7-max`（接入端 `bailian-token-plan`，通过 `@ai-sdk/anthropic` 适配层调用）在 agent 多轮对话场景下，会**自发输出 Claude Code 专有的 `<analysis>` + `<summary>` 上下文压缩模板**作为纯文本，然后以 `finish_reason=stop` 提前终止生成。

- 触发后 agent 循环退出（无后续 tool call），用户感知为"agent 突然死掉"
- 模型输出的内容是 Claude Code（Anthropic 内部工具）的对话压缩协议产物，并非用户/系统期望的输出
- 推测原因：训练数据中混入了 Claude Code 的对话日志，模型在 agent 长上下文场景下复读训练片段

---

## 二、统计证据

数据库 `~/.local/share/opencode/opencode.db` 全量查询：

| 指标 | 数值 |
|---|---|
| 命中条数（assistant 输出含 `<analysis>` / `<summary>` / `<thought>` 且 `finish=stop` 且 `modelID=qwen3.7-max`） | **134** |
| 涉及 session 数 | **12** |
| 时间跨度 | 2026-05-23 10:26:31 ~ 2026-05-25 01:52:46 |
| 其他模型（claude-*, gpt-*）命中数 | **0** |

> 结论：**100% 集中在 `qwen3.7-max`**，其他模型零命中，证明非框架问题。

---

## 三、复现条件

| 条件 | 必需 |
|---|---|
| 模型 | `qwen3.7-max`（任何路由端，已确认 bailian-token-plan 复现） |
| 上下文长度 | ≥ 80k tokens（典型命中均 84k~440k 输入） |
| Agent 场景 | 多轮 tool 调用对话（OpenCode、Claude Code 风格） |
| System prompt 中是否提及"summary/compress" | **否**（即使禁止 `<analysis>`/`<summary>` 标签仍会触发） |

**触发率**：在 80k+ context 的 qwen3.7-max session 中，单 session 内可重复触发 10+ 次（见 session `ses_1a346511dffeMuGlOGc3t4LOC8`）。

---

## 四、API finish 状态

抓取自 `~/.local/share/opencode/log/2026-05-25T012848.log`：

```
finishReason=stop hasToolCalls=false step=12 tokens={total:84782,output:254} model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=1  tokens={total:84947,output:434} model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=4  tokens={total:86876,output:3}   model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=3  tokens={total:88211,output:306} model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=7  tokens={total:90705,output:78}  model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=12 tokens={total:95099,output:248} model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=6  tokens={total:102538,output:358} model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=2  tokens={total:115472,output:927} model=qwen3.7-max exiting loop
finishReason=stop hasToolCalls=false step=26 tokens={total:105882,output:490} model=qwen3.7-max exiting loop
```

注意 `step=4 output=3` 这种极端情况：模型生成 3 个 token 即返回 stop。

---

## 五、典型输出样本（核心证据）

### 样本特征

模型输出的文本完全匹配 **Anthropic Claude Code** 的内部对话压缩格式：

```xml
<analysis>
[Let me trace through the conversation chronologically:
...编号小节，分析对话演进...]
</analysis>

<summary>
1. Primary Request and Intent: ...
2. Key Technical Concepts: ...
3. Files and Code Sections: ...
4. Errors and Fixes: ...
5. Problem Solving: ...
6. All User Messages: ...
7. Pending Tasks: ...
8. Current Work: ...
9. Optional Next Step: ...
</summary>
```

这是 Claude Code（**Anthropic 内部产品**）的 `/compact` 命令输出协议。Qwen3.7-Max 不应该知道此协议结构，更不应当复现。

### 完整样本文件

| 文件 | 大小 | 来源 message_id |
|---|---|---|
| `specimen-short-8.8k.txt` | 8808 字节 | `msg_e5cb9bb83001bkSVK01GhXTaVH` |
| `specimen-long-11k.txt` | 12852 字节 | `msg_e5cb9c09e001DWdM9KJXjnWJxb` |

样本片段（specimen-short 开头）：

```
<analysis>
Let me trace through the conversation chronologically:

**From compressed blocks (b3, b4, b5):**
- DCP Compress Bug: Root cause was `inject.ts:52-58` clearing nudge anchors after compress without injecting continuation guidance. Fixed by injecting `<system-reminder>Compression complete. Resume your previous task from where you left off.</system-reminder>`. Also cherry-picked PR #530 for state persistence...
```

> 注意输出中的 `<system-reminder>` 标签同样是 Claude Code 协议标签，进一步印证训练数据污染来源。

---

## 六、调用方系统提示词（排除自身嫌疑）

OpenCode + DCP 插件向 `qwen3.7-max` 发送的 system prompt 不含 `<analysis>` / `<summary>` 字样。当前部署的 DCP 系统提示词（`~/.config/opencode/plugins/opencode-dcp/lib/prompts/system.ts`）：

```
你在一个上下文受限的环境中运行。持续管理上下文以避免堆积并保持检索质量。
...
关键约束
- 上下文管理仅通过调用 compress 工具完成。绝不以纯文本形式生成摘要。
- **严格禁止**在文本响应中输出 <summary> 或 <analysis> XML 标签。这些标签会导致系统错误。
- 如果你认为上下文需要压缩，调用 compress 工具。不要内联编写摘要。
- 所有输出必须使用中文。
- 如果需要在文本中组织信息，使用 Markdown 格式（如 ## 分析、## 总结），绝不使用 XML 标签。
```

**即使 system prompt 显式禁止该格式**，qwen3.7-max 仍会输出此模板 → 排除 prompt 注入嫌疑，确认模型行为问题。

---

## 七、对比验证

| 模型 | 同等上下文（80k~440k） | `<analysis>` + `<summary>` 输出 | finish=stop 异常 |
|---|---|---|---|
| qwen3.7-max | ✅ 测试 | ✅ 134 次 | ✅ 频繁 |
| claude-sonnet-4.5 | ✅ 长期使用 | ❌ 0 次 | ❌ |
| gpt-4o / gpt-5 | ✅ 长期使用 | ❌ 0 次 | ❌ |

---

## 八、建议根因方向

1. **训练语料污染**：训练数据混入了 Claude Code 的 agent 对话日志（含其 `/compact`、`<analysis>`、`<summary>`、`<system-reminder>` 内部协议）
2. **长上下文激活**：上下文超过某阈值（实测 ~80k）后，模型从"完成用户任务"模式漂移到"复读训练数据中的压缩段"
3. **SFT 数据筛选漏过 Anthropic 内部标签**：建议在数据清洗阶段过滤 Claude Code 专有标签

---

## 九、建议厂商验证步骤

1. 检索训练语料库中是否存在 `<analysis>`...`</analysis>`\n\n`<summary>` 的紧邻模式
2. 在 80k+ context 下用 OpenCode 或任何 Anthropic-API 兼容的 agent 框架对 qwen3.7-max 长时间多轮对话
3. 监控 finish_reason=stop 且 output_tokens < 1000 的事件
4. 检查 instruct/SFT 训练集中是否标注了 Anthropic Claude Code 的对话日志

---

## 十、附件清单

```
_note_/qwen3.7-max-premature-stop-bug-report.md   ← 本文件
_note_/specimen-short-8.8k.txt                    ← 短样本（完整 <analysis>+<summary>）
_note_/specimen-long-11k.txt                      ← 长样本（更详细的 9 节模板）
```

数据来源：
- `~/.local/share/opencode/opencode.db`（OpenCode 主数据库，SQLite）
- `~/.local/share/opencode/log/2026-05-25T012848.log`（详细 finishReason 日志）